const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Path to JSON database
const dbPath = path.join(__dirname, "data", "users.json");

// Helper function to read JSON
const readUsers = () => {
  try {
    const data = fs.readFileSync(dbPath, "utf-8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading DB:", err);
    return [];
  }
};

// Helper function to write JSON
const writeUsers = (users) => {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(users, null, 2));
  } catch (err) {
    console.error("Error writing DB:", err);
  }
};

// GET all users
app.get("/api/users", (req, res) => {
  const users = readUsers();
  res.json(users);
});

// POST new user
app.post("/api/users", (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({ message: "Name & Email required" });
  }

  const users = readUsers();

  const newUser = {
    id: Date.now(),
    name,
    email
  };

  users.push(newUser);
  writeUsers(users);

  res.status(201).json(newUser);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${5000}`);
});
